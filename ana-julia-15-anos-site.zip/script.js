// ==============================
// CONFIGURAÇÃO
// ==============================
// Cole abaixo a URL do Web App criado no Google Apps Script.
// Enquanto estiver com o valor abaixo, o site funcionará em "modo demonstração".
const GOOGLE_SCRIPT_URL = "COLE_AQUI_A_URL_DO_GOOGLE_APPS_SCRIPT";

// Data da festa: 12/09/2026 às 21h
const EVENT_DATE = new Date("2026-09-12T21:00:00-03:00");

// ==============================
// CONTAGEM REGRESSIVA
// ==============================
function updateCountdown() {
  const now = new Date();
  const diff = EVENT_DATE - now;

  const ids = ["days", "hours", "minutes", "seconds"];

  if (diff <= 0) {
    ids.forEach(id => document.getElementById(id).textContent = "00");
    return;
  }

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((diff / (1000 * 60)) % 60);
  const seconds = Math.floor((diff / 1000) % 60);

  document.getElementById("days").textContent = String(days).padStart(2, "0");
  document.getElementById("hours").textContent = String(hours).padStart(2, "0");
  document.getElementById("minutes").textContent = String(minutes).padStart(2, "0");
  document.getElementById("seconds").textContent = String(seconds).padStart(2, "0");
}

updateCountdown();
setInterval(updateCountdown, 1000);

// ==============================
// CAMPOS CONDICIONAIS
// ==============================
const presenca = document.getElementById("presenca");
const van = document.getElementById("van");
const acompanhantesField = document.getElementById("acompanhantesField");
const vanField = document.getElementById("vanField");
const vanQtdField = document.getElementById("vanQtdField");

function syncFields() {
  const vai = presenca.value === "Sim";
  acompanhantesField.classList.toggle("hidden", !vai);
  vanField.classList.toggle("hidden", !vai);

  if (!vai) {
    van.value = "";
    vanQtdField.classList.add("hidden");
  } else {
    vanQtdField.classList.toggle("hidden", van.value !== "Sim");
  }
}

presenca.addEventListener("change", syncFields);
van.addEventListener("change", syncFields);
syncFields();

// ==============================
// ENVIO DO FORMULÁRIO
// ==============================
const form = document.getElementById("rsvpForm");
const message = document.getElementById("formMessage");

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const button = form.querySelector("button[type='submit']");
  const dataEnvio = document.getElementById("dataEnvio");
  dataEnvio.value = new Date().toLocaleString("pt-BR");

  if (presenca.value === "Sim" && !van.value) {
    message.textContent = "Informe se deseja utilizar a van.";
    return;
  }

  button.disabled = true;
  button.textContent = "Enviando...";
  message.textContent = "";

  const payload = Object.fromEntries(new FormData(form).entries());

  try {
    if (GOOGLE_SCRIPT_URL.includes("COLE_AQUI")) {
      console.log("Modo demonstração — dados que seriam enviados:", payload);
      await new Promise(resolve => setTimeout(resolve, 700));
    } else {
      await fetch(GOOGLE_SCRIPT_URL, {
        method: "POST",
        mode: "no-cors",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
    }

    message.textContent = "Confirmação enviada com sucesso! 💙";
    form.reset();
    syncFields();
  } catch (error) {
    console.error(error);
    message.textContent = "Não foi possível enviar. Tente novamente em alguns instantes.";
  } finally {
    button.disabled = false;
    button.textContent = "Enviar confirmação";
  }
});
