# Site 15 anos — Ana Júlia

Este projeto contém um site estático completo com:

- página inicial do convite;
- contagem regressiva;
- informações da festa;
- confirmação de presença;
- confirmação da van;
- quantidade de convidados;
- quantidade de vagas na van;
- integração com Google Sheets via Google Apps Script;
- layout responsivo para celular.

## 1. Arquivos

- `index.html` — conteúdo do site.
- `style.css` — aparência.
- `script.js` — comportamento, contagem regressiva e envio do formulário.
- `google-apps-script.js` — código para salvar respostas em uma planilha.

## 2. Testar no computador

Abra `index.html` no navegador.

O formulário inicialmente trabalha em modo demonstração. Isso permite testar a página antes de configurar a planilha.

## 3. Criar a planilha de confirmações

1. Acesse o Google Sheets.
2. Crie uma planilha chamada, por exemplo, `Confirmacoes Ana Julia 15 anos`.
3. Na planilha, clique em `Extensões > Apps Script`.
4. Apague o código padrão.
5. Copie todo o conteúdo de `google-apps-script.js`.
6. Cole no editor.
7. Clique em salvar.

## 4. Publicar o Apps Script

1. No Apps Script, clique em `Implantar`.
2. Clique em `Nova implantação`.
3. Escolha `Aplicativo da Web`.
4. Em `Executar como`, selecione sua própria conta.
5. Em `Quem pode acessar`, escolha `Qualquer pessoa`.
6. Clique em `Implantar`.
7. Autorize o acesso quando o Google solicitar.
8. Copie a URL terminada em `/exec`.

## 5. Conectar o site à planilha

Abra `script.js`.

Localize:

```js
const GOOGLE_SCRIPT_URL = "COLE_AQUI_A_URL_DO_GOOGLE_APPS_SCRIPT";
```

Troque pelo endereço copiado no Apps Script:

```js
const GOOGLE_SCRIPT_URL = "https://script.google.com/macros/s/SEU_ID/exec";
```

Salve o arquivo.

## 6. Publicar gratuitamente no GitHub Pages

### Criar repositório

1. Entre no GitHub.
2. Clique em `New repository`.
3. Nome sugerido: `ana-julia-15-anos`.
4. Marque como `Public`.
5. Clique em `Create repository`.

### Enviar os arquivos

No repositório:

1. Clique em `Add file`.
2. Clique em `Upload files`.
3. Arraste para a página:
   - `index.html`
   - `style.css`
   - `script.js`
4. Clique em `Commit changes`.

> Não é necessário publicar `google-apps-script.js` junto com o site. Ele fica no Google Apps Script.

### Ativar GitHub Pages

1. Abra `Settings`.
2. No menu lateral, clique em `Pages`.
3. Em `Build and deployment`, escolha:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Pasta: `/root`
4. Clique em `Save`.

O GitHub exibirá o endereço do site.

Normalmente ele terá o formato:

`https://SEU-USUARIO.github.io/ana-julia-15-anos/`

## 7. Alterar informações da festa

No `index.html`, você pode editar:

- data;
- horário;
- local;
- texto de abertura;
- instruções da van;
- mensagem final.

A contagem regressiva está configurada no `script.js`:

```js
const EVENT_DATE = new Date("2026-09-12T21:00:00-03:00");
```

## 8. Personalização visual

As cores principais ficam no começo de `style.css`, na seção `:root`.

Você pode trocar os tons de azul sem alterar o restante do código.

## 9. Teste final recomendado

Antes de enviar o convite:

1. acesse pelo celular;
2. envie uma confirmação de teste;
3. confira se a linha apareceu no Google Sheets;
4. teste uma resposta com van;
5. teste uma resposta sem van;
6. teste uma resposta de ausência.
