/**
 * Google Apps Script para receber as confirmações do site
 * e salvar em uma planilha do Google Sheets.
 *
 * PASSOS:
 * 1. Crie uma planilha no Google Sheets.
 * 2. Vá em Extensões > Apps Script.
 * 3. Apague o código existente e cole este arquivo.
 * 4. Troque "NOME_DA_ABA" pelo nome da sua aba, se desejar.
 * 5. Implantar > Nova implantação > Aplicativo da Web.
 * 6. Executar como: você.
 * 7. Quem pode acessar: Qualquer pessoa.
 * 8. Copie a URL e cole em script.js.
 */

const SHEET_NAME = "Confirmacoes";

function doPost(e) {
  try {
    const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = spreadsheet.getSheetByName(SHEET_NAME);

    if (!sheet) {
      sheet = spreadsheet.insertSheet(SHEET_NAME);
      sheet.appendRow([
        "Data/Hora",
        "Nome",
        "WhatsApp",
        "Presença",
        "Qtd. pessoas",
        "Van",
        "Qtd. vagas van",
        "Observação"
      ]);
    }

    const data = JSON.parse(e.postData.contents);

    sheet.appendRow([
      data.dataEnvio || new Date(),
      data.nome || "",
      data.telefone || "",
      data.presenca || "",
      data.acompanhantes || "",
      data.van || "",
      data.vanQtd || "",
      data.observacao || ""
    ]);

    return ContentService
      .createTextOutput(JSON.stringify({ status: "ok" }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (error) {
    return ContentService
      .createTextOutput(JSON.stringify({ status: "erro", message: String(error) }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
