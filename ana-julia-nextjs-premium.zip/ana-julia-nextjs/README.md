# Ana Júlia — 15 anos

Site Next.js 15 com visual premium em azul, branco e prata, animação de borboletas em CSS 3D, galeria, contagem regressiva, mapa, van, presentes e RSVP integrado ao Google Sheets.

## Publicar no repositório existente

1. Faça backup dos arquivos atuais.
2. Substitua o conteúdo do repositório pelos arquivos deste projeto, mantendo a estrutura de pastas.
3. No GitHub, faça commit na branch `main`.
4. Em `Settings > Pages`, altere **Source** de `Deploy from a branch` para **GitHub Actions**.
5. O workflow `.github/workflows/deploy-pages.yml` fará o build e publicará automaticamente.

O `next.config.mjs` detecta o nome do repositório no GitHub Actions e configura automaticamente o `basePath`, então o site funciona em endereços do tipo `usuario.github.io/nome-do-repositorio/`.

## Google Sheets / RSVP

1. Crie uma planilha no Google Sheets.
2. Acesse `Extensões > Apps Script`.
3. Cole o conteúdo do arquivo `google-apps-script.js`.
4. Clique em `Implantar > Nova implantação > Aplicativo da Web`.
5. Executar como: você.
6. Quem pode acessar: qualquer pessoa.
7. Copie a URL `/exec`.
8. No GitHub, abra `Settings > Secrets and variables > Actions > New repository secret`.
9. Nome: `NEXT_PUBLIC_GOOGLE_SCRIPT_URL`.
10. Valor: a URL `/exec` do Apps Script.
11. Faça um novo commit ou execute manualmente o workflow em `Actions` para republicar.

## Testar localmente

```bash
npm install
npm run dev
```

Abra `http://localhost:3000`.

## Fotos da galeria

O projeto vem com placeholders elegantes para não usar fotos que não sejam da Ana Júlia. Quando tiver as fotos finais, coloque-as em `public/gallery/` e troque os placeholders por `<img>` ou `next/image` em `app/page.tsx`.

## Alterar dados da festa

Edite `config/site.ts` para trocar data, local, texto, informações da van e presentes.

## Lista de presentes

Os cards já estão prontos visualmente. Quando decidir onde será a lista (Pix, loja, site, etc.), adicione uma propriedade `url` aos itens em `config/site.ts` e substitua o botão em `app/page.tsx` por um link.
