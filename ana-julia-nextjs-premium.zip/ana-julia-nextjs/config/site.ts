export const siteConfig = {
  celebrant: 'Ana Júlia',
  eventTitle: '15 anos',
  eventDate: '2026-09-12T21:00:00-03:00',
  eventDateLabel: '12 de setembro de 2026',
  eventTimeLabel: '21h',
  venue: 'Fly Eventos',
  city: 'Varginha • MG',
  mapsQuery: 'Fly Eventos Varginha MG',
  intro:
    'Cada borboleta representa transformação, liberdade e novos sonhos. Quero celebrar essa nova etapa da minha vida ao lado das pessoas que amo, reunindo família e amigos para viver uma noite inesquecível.',
  van: {
    title: 'Reserva de van',
    text: 'Se você pretende utilizar a van, informe no RSVP. Os detalhes de ponto de encontro e horário serão enviados aos convidados confirmados.'
  },
  gifts: [
    { title: 'Um novo sonho', description: 'Uma contribuição simbólica para os próximos capítulos dessa nova fase.' },
    { title: 'Dia de princesa', description: 'Um mimo para tornar os preparativos e lembranças ainda mais especiais.' },
    { title: 'Experiências', description: 'Uma contribuição para viagens, passeios e momentos inesquecíveis.' },
    { title: 'Presente surpresa', description: 'Prefere escolher algo com carinho? Toda lembrança será recebida com amor.' }
  ]
};
