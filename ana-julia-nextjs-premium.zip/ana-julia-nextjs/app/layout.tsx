import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Ana Júlia | 15 anos',
  description: 'Convite oficial para os 15 anos da Ana Júlia.'
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
