import Butterflies from '@/components/Butterflies';
import Countdown from '@/components/Countdown';
import RsvpForm from '@/components/RsvpForm';
import { siteConfig } from '@/config/site';

const gallery = [
  { label: 'Ensaio principal', className: 'galleryOne' },
  { label: 'Momentos', className: 'galleryTwo' },
  { label: 'Detalhes', className: 'galleryThree' },
  { label: 'Memórias', className: 'galleryFour' },
  { label: 'Uma nova fase', className: 'galleryFive' }
];

export default function Home() {
  const mapSrc = `https://www.google.com/maps?q=${encodeURIComponent(siteConfig.mapsQuery)}&output=embed`;

  return (
    <main>
      <section className="hero" id="inicio">
        <div className="heroGlow" />
        <div className="stars" />
        <Butterflies />

        <nav className="nav shell">
          <a className="monogram" href="#inicio" aria-label="Ana Júlia">AJ</a>
          <div className="navLinks">
            <a href="#sobre">Sobre</a>
            <a href="#galeria">Galeria</a>
            <a href="#local">Local</a>
            <a href="#presentes">Presentes</a>
          </div>
          <a className="navButton" href="#rsvp">RSVP</a>
        </nav>

        <div className="heroContent shell">
          <div className="heroCopy">
            <p className="overline">Uma noite para guardar para sempre</p>
            <span className="fifteen">15 anos</span>
            <h1>Ana Júlia</h1>
            <div className="ornament"><span /><b>✦</b><span /></div>
            <p className="heroText">{siteConfig.intro}</p>

            <div className="heroFacts">
              <div><span className="factIcon">◇</span><p><strong>{siteConfig.eventDateLabel}</strong><small>Sábado • {siteConfig.eventTimeLabel}</small></p></div>
              <div><span className="factIcon">⌖</span><p><strong>{siteConfig.venue}</strong><small>{siteConfig.city}</small></p></div>
            </div>

            <a className="primaryButton" href="#rsvp">Confirmar presença</a>
          </div>

          <div className="heroArt" aria-hidden="true">
            <div className="glassOrb orbOne" />
            <div className="glassOrb orbTwo" />
            <div className="heroButterfly">
              <span className="largeWing left" />
              <span className="largeWing right" />
              <span className="largeBody" />
            </div>
            <div className="sparkleRing" />
          </div>
        </div>
      </section>

      <section className="countdownWrap shell">
        <Countdown target={siteConfig.eventDate} />
      </section>

      <section className="quickNav shell" aria-label="Atalhos">
        <a href="#sobre"><span>♕</span>Sobre este dia</a>
        <a href="#galeria"><span>▧</span>Galeria</a>
        <a href="#local"><span>⌖</span>Localização</a>
        <a href="#van"><span>▱</span>Reserva de van</a>
        <a href="#presentes"><span>◇</span>Presentes</a>
        <a href="#rsvp"><span>✉</span>Confirmar presença</a>
      </section>

      <section className="section about" id="sobre">
        <div className="shell aboutGrid">
          <article className="storyCard">
            <p className="eyebrow">Sobre este dia</p>
            <h2>Abrir as asas para uma nova fase.</h2>
            <p>Celebrar 15 anos é viver um capítulo cheio de sonhos, descobertas e novas possibilidades. E esse momento só faz sentido cercado pelas pessoas que fazem parte da minha história.</p>
            <p>Preparei cada detalhe com muito carinho e espero você para tornar essa noite ainda mais inesquecível.</p>
            <div className="signature">Com amor,<br /><strong>Ana Júlia</strong></div>
          </article>

          <div className="quotePanel">
            <div className="silverLine" />
            <span className="quoteMark">“</span>
            <blockquote>Cada borboleta representa transformação, liberdade e novos sonhos.</blockquote>
            <span className="miniButterfly">🦋</span>
          </div>
        </div>
      </section>

      <section className="section gallerySection" id="galeria">
        <div className="shell">
          <div className="sectionHead">
            <p className="eyebrow">Memórias & sonhos</p>
            <h2>Galeria de momentos</h2>
            <p>Espaços preparados para as fotos do ensaio da Ana Júlia. Basta substituir as imagens na pasta <code>public/gallery</code>.</p>
          </div>

          <div className="galleryGrid">
            {gallery.map((item, index) => (
              <figure className={`galleryCard ${item.className}`} key={item.label}>
                <div className="photoPlaceholder">
                  <span>{String(index + 1).padStart(2, '0')}</span>
                  <strong>{item.label}</strong>
                  <small>Adicionar foto</small>
                </div>
              </figure>
            ))}
          </div>
        </div>
      </section>

      <section className="section venueSection" id="local">
        <div className="shell venueGrid">
          <div className="venueCopy">
            <p className="eyebrow">Onde tudo acontece</p>
            <h2>{siteConfig.venue}</h2>
            <p className="venueCity">{siteConfig.city}</p>
            <p>Uma noite especial merece um cenário à altura. Consulte o mapa e programe sua chegada com tranquilidade.</p>
            <a className="outlineButton" href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(siteConfig.mapsQuery)}`} target="_blank" rel="noreferrer">Abrir no Google Maps</a>
          </div>
          <div className="mapCard">
            <iframe title="Mapa do Fly Eventos" src={mapSrc} loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
          </div>
        </div>
      </section>

      <section className="section featureSection" id="van">
        <div className="shell featureGrid">
          <article className="featureCard vanCard">
            <div className="featureIcon">▰</div>
            <p className="eyebrow">Transporte</p>
            <h3>{siteConfig.van.title}</h3>
            <p>{siteConfig.van.text}</p>
            <a href="#rsvp" className="outlineButton light">Reservar lugar</a>
          </article>

          <article className="featureCard etiquetteCard">
            <div className="featureIcon">✦</div>
            <p className="eyebrow">Dress code</p>
            <h3>Traje social</h3>
            <p>Venha elegante e confortável para celebrar, dançar e viver uma noite inesquecível.</p>
            <span className="note">Azul royal e azul-marinho ficam reservados para a protagonista da noite.</span>
          </article>
        </div>
      </section>

      <section className="section giftsSection" id="presentes">
        <div className="shell">
          <div className="sectionHead">
            <p className="eyebrow">Com carinho</p>
            <h2>Lista de presentes</h2>
            <p>Sua presença é o maior presente. Para quem quiser deixar uma lembrança, estas são algumas ideias.</p>
          </div>
          <div className="giftGrid">
            {siteConfig.gifts.map((gift, index) => (
              <article className="giftCard" key={gift.title}>
                <span className="giftNumber">0{index + 1}</span>
                <div className="giftIcon">◇</div>
                <h3>{gift.title}</h3>
                <p>{gift.description}</p>
                <button className="giftButton" type="button">Escolher presente</button>
              </article>
            ))}
          </div>
          <p className="giftHint">Os botões estão prontos visualmente. Você pode trocar cada um por links reais de lojas, PIX ou lista online no arquivo <code>config/site.ts</code>.</p>
        </div>
      </section>

      <section className="section rsvpSection" id="rsvp">
        <div className="shell rsvpGrid">
          <div className="rsvpIntro">
            <p className="eyebrow">RSVP</p>
            <h2>Confirme sua presença</h2>
            <p>Ajude a organizar cada detalhe dessa noite. No mesmo formulário você também poderá reservar as vagas da van.</p>
            <div className="rsvpBadge"><span>12</span><small>SET<br />2026</small></div>
          </div>
          <RsvpForm />
        </div>
      </section>

      <footer className="footer">
        <Butterflies />
        <div className="footerMonogram">AJ</div>
        <h2>Espero você para viver esse sonho comigo.</h2>
        <p>Ana Júlia • 15 anos • 12 de setembro de 2026</p>
      </footer>
    </main>
  );
}
