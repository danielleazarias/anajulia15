'use client';

import { FormEvent, useState } from 'react';

const endpoint = process.env.NEXT_PUBLIC_GOOGLE_SCRIPT_URL || '';

type Status = 'idle' | 'loading' | 'success' | 'error';

export default function RsvpForm() {
  const [status, setStatus] = useState<Status>('idle');
  const [presence, setPresence] = useState('Sim');
  const [van, setVan] = useState('Não');

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const formData = new FormData(form);
    const payload = Object.fromEntries(formData.entries());
    payload.dataEnvio = new Date().toLocaleString('pt-BR');
    setStatus('loading');

    try {
      if (!endpoint) {
        console.info('RSVP em modo demonstração:', payload);
        await new Promise((resolve) => setTimeout(resolve, 650));
      } else {
        await fetch(endpoint, {
          method: 'POST',
          mode: 'no-cors',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
      }
      setStatus('success');
      form.reset();
      setPresence('Sim');
      setVan('Não');
    } catch {
      setStatus('error');
    }
  }

  return (
    <form className="rsvpForm" onSubmit={submit}>
      <div className="field fullField">
        <label htmlFor="nome">Nome completo</label>
        <input id="nome" name="nome" required placeholder="Digite seu nome" />
      </div>

      <div className="field">
        <label htmlFor="telefone">WhatsApp</label>
        <input id="telefone" name="telefone" required placeholder="(00) 00000-0000" />
      </div>

      <div className="field">
        <label htmlFor="presenca">Presença</label>
        <select id="presenca" name="presenca" value={presence} onChange={(e) => setPresence(e.target.value)}>
          <option>Sim</option>
          <option>Não</option>
        </select>
      </div>

      {presence === 'Sim' && (
        <>
          <div className="field">
            <label htmlFor="acompanhantes">Quantidade de pessoas</label>
            <select id="acompanhantes" name="acompanhantes" defaultValue="1">
              {[1,2,3,4,5].map(n => <option key={n} value={n}>{n} {n === 1 ? 'pessoa' : 'pessoas'}</option>)}
            </select>
          </div>

          <div className="field">
            <label htmlFor="van">Vai utilizar a van?</label>
            <select id="van" name="van" value={van} onChange={(e) => setVan(e.target.value)}>
              <option>Não</option>
              <option>Sim</option>
            </select>
          </div>

          {van === 'Sim' && (
            <div className="field fullField">
              <label htmlFor="vanQtd">Quantas vagas na van?</label>
              <select id="vanQtd" name="vanQtd" defaultValue="1">
                {[1,2,3,4,5].map(n => <option key={n} value={n}>{n} {n === 1 ? 'vaga' : 'vagas'}</option>)}
              </select>
            </div>
          )}
        </>
      )}

      <div className="field fullField">
        <label htmlFor="observacao">Observação</label>
        <textarea id="observacao" name="observacao" rows={4} placeholder="Deixe uma mensagem ou informação importante" />
      </div>

      <button className="primaryButton fullField" type="submit" disabled={status === 'loading'}>
        {status === 'loading' ? 'Enviando...' : 'Confirmar presença'}
      </button>

      {status === 'success' && <p className="formSuccess fullField">Confirmação enviada com sucesso. 💙</p>}
      {status === 'error' && <p className="formError fullField">Não foi possível enviar. Tente novamente.</p>}
      {!endpoint && <p className="formHint fullField">O formulário está em modo demonstração até a URL do Google Sheets ser configurada.</p>}
    </form>
  );
}
