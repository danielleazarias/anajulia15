export default function Butterflies() {
  return (
    <div className="butterflyField" aria-hidden="true">
      {Array.from({ length: 9 }).map((_, index) => (
        <span className={`butterfly b${index + 1}`} key={index}>
          <i className="wing leftWing" />
          <i className="wing rightWing" />
          <i className="body" />
        </span>
      ))}
    </div>
  );
}
