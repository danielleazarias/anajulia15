'use client';

import { useEffect, useMemo, useState } from 'react';

function getTimeLeft(target: string) {
  const distance = Math.max(0, new Date(target).getTime() - Date.now());
  return {
    days: Math.floor(distance / 86400000),
    hours: Math.floor((distance / 3600000) % 24),
    minutes: Math.floor((distance / 60000) % 60),
    seconds: Math.floor((distance / 1000) % 60)
  };
}

export default function Countdown({ target }: { target: string }) {
  const [time, setTime] = useState(() => getTimeLeft(target));

  useEffect(() => {
    const timer = setInterval(() => setTime(getTimeLeft(target)), 1000);
    return () => clearInterval(timer);
  }, [target]);

  const items = useMemo(() => [
    ['Dias', time.days],
    ['Horas', time.hours],
    ['Minutos', time.minutes],
    ['Segundos', time.seconds]
  ], [time]);

  return (
    <div className="countdownPanel">
      <div className="countdownTitle"><span />Falta pouco!<span /></div>
      <div className="countdownGrid">
        {items.map(([label, value]) => (
          <div className="countdownItem" key={String(label)}>
            <strong>{String(value).padStart(2, '0')}</strong>
            <small>{label}</small>
          </div>
        ))}
      </div>
    </div>
  );
}
