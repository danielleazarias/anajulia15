const SHEET_NAME = 'Confirmacoes';

function doPost(e) {
  try {
    const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = spreadsheet.getSheetByName(SHEET_NAME);

    if (!sheet) {
      sheet = spreadsheet.insertSheet(SHEET_NAME);
      sheet.appendRow([
        'Data/Hora', 'Nome', 'WhatsApp', 'Presença',
        'Qtd. pessoas', 'Van', 'Qtd. vagas van', 'Observação'
      ]);
    }

    const data = JSON.parse(e.postData.contents);
    sheet.appendRow([
      data.dataEnvio || new Date(),
      data.nome || '',
      data.telefone || '',
      data.presenca || '',
      data.acompanhantes || '',
      data.van || '',
      data.vanQtd || '',
      data.observacao || ''
    ]);

    return ContentService
      .createTextOutput(JSON.stringify({ status: 'ok' }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (error) {
    return ContentService
      .createTextOutput(JSON.stringify({ status: 'error', message: String(error) }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
